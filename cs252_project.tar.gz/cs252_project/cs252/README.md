# cs252-project-lost-and-found-

After installing pycharm on your machine 

open folder : /run/user/1000/sftp://ubuntu@ssh ubuntu@172.27.43.36/home/cs252/ 

This is your project 

Local Host: 
Set up procedure... "Make File" will be uploaded later: 

--> sudo apt-get install mysql-serve  
--> sudo mysql_secure_installation  
--> sudo mysql_install_db   
--> sudo apt-get install libmysqlclient-dev  
--> sudo apt-get install libmysqlclient-dev python-dev  
--> sudo apt-get install python-pip  
--> sudo apt-get install python-setuptools  
--> sudo apt-get install python-MySQLdb  
--> sudo pip install mysql-python  
--> sudo python easyinstall.py  
--> sudo easy_install django  
--> make database lost in mysql and accordingly change username and pasword of mysql using settings.py in cs252 folder   

--> python manage.py makemigrations  
--> pythan manage.py migrate  
--> python manage.py runserver 


